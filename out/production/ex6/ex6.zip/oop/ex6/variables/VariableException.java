package oop.ex6.variables;

/**
 * class suits for exceptions of variables
 */
public class VariableException extends Exception {
    public VariableException(String s){
        super(s);
    }
}
