package oop.ex6.methods;

/**
 * class suits for exceptions of methods
 */
public class MethodException extends Exception {

    public MethodException(String s){
        super(s);
    }
}
