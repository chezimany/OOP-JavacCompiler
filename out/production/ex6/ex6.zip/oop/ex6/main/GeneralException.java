package oop.ex6.main;

/**
 * a class for general exceptions
 */
public class GeneralException extends Exception {

    public GeneralException(String s){
        super(s);
    }
}
