package oop.ex6.ifAndWhileBlocks;

/**
 * object representing an if block
 */
public class IfBlock extends Block {

    public IfBlock(String condition, int startRow) {
        super(condition, startRow);
    }

}
