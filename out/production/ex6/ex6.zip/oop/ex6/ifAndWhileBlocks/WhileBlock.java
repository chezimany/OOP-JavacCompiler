package oop.ex6.ifAndWhileBlocks;

/**
 * object representing a while block
 */
public class WhileBlock extends Block {

    public WhileBlock(String condition, int startRow) {
        super(condition, startRow);
    }

}
