package oop.ex6.ifAndWhileBlocks;

/**
 * class suits for exceptions of blocks
 */
public class BlockException extends Exception{

    public BlockException(String s){
        super(s);
    }

}
